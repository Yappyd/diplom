package com.yappyd.chatservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
