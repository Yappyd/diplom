package com.yappyd.chatservice.dto.responce;

import java.util.UUID;

public record CreatePrivateChatResponse(
        UUID chatId
) {
}
